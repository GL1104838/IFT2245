Auteur 1
========
Nom:
Matricule:
Courriel:

Auteur 2
========
Nom:
Matricule:
Courriel:
